Student: Joaquin Saldana 
CS325 / Intro to Algorithms 
Homework 1 

Below is information on how to compile the necessary files 

The homework was written in python programming language

==================================================================

insertsort.py 

before executing the file you will want to ensure it's file permissions is an executable.  Please enter the following 
command into the prompt line 

chmod +x insertsort.py 

afterwards you may just entere insertsort.py into the command line to run the python file 

==================================================================

mergesort.py

before executing the file you will want to ensure it's file permissions is an executable.  Please enter the following 
command into the prompt line 

chmod +x mergesort.py 

afterwards you may just entere insertsort.py into the command line to run the python file 


