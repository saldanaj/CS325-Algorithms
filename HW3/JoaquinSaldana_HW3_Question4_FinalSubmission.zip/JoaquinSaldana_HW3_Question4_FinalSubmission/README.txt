Student: Joaquin Saldana 
CS325 Intro To Algorithms 
Homework 3 / Question 4

Below is information on how to compile the necessary files 

The homework was written in python programming language

==================================================================

makechange_dp.py

before executing the file you will want to ensure it's file permissions is an executable.  Please enter the following 
command into the prompt line 

chmod +x makechange_dp.py

afterwards you may just enter makechange_dp.py into the command line to run the python file 

Note: I've also included a amount.txt file as a sample.  This should work w/ any amount.txt file. 