Student: Joaquin Saldana 
CS325 Intro To Algorithms 
Homework 2 / Question 5

Below is information on how to compile the necessary files 

The homework was written in python programming language

==================================================================

stoogesort.py 

before executing the file you will want to ensure it's file permissions is an executable.  Please enter the following 
command into the prompt line 

chmod +x stoogesort.py 

afterwards you may just enter stoogesort.py into the command line to run the python file 

Note: I've also included a data.txt file as a sample.  This should work w/ any data.txt file. 